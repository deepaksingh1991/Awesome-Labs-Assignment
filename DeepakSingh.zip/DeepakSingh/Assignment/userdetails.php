<?php 
include 'connection.php';
$name = $_POST['user_name']; 
$email = $_POST['user_email'];
$contact_number =  $_POST['user_contact'];
$gender = $_POST['user_gender'];
$address = $_POST['user_address'];
$name = mysqli_real_escape_string($conn,$name);
$email = mysqli_real_escape_string($conn,$email);
$contact_number = mysqli_real_escape_string($conn,$contact_number);
$gender= mysqli_real_escape_string($conn,$gender);
$address= mysqli_real_escape_string($conn,$address);

/*$name = "deepak";
$email = "deepak@gmail.com";
$contact_number =  "8156973493";
$gender = "male";
$address = "Uttar Pradesh";*/
$sql_query = "select * from tUserdetails where email like '" .$email. "';";
$result = mysqli_query($conn,$sql_query);
if(mysqli_num_rows($result)>0)
{
    $response = array();
    $code = "reg_false";
    $message = "User Already Exist";
  array_push($response,array("code" => $code, "message" => $message));
  echo json_encode(array("server_response" => $response));
}
else
{
      $sql = " INSERT INTO tUserdetails  (name,email,contact_number,gender,address) values ('" .$name. "', '" .$email. "', '" .$contact_number. "', '" .$gender."', '" .$address. "') ;";

      $result = mysqli_query($conn, $sql);
         if(!$result)
        {
             $response = array();
             $code = "reg_false";
             $message = "Some Server Error occured try again .....";
             array_push($response,array("code" => $code, "message" => $message));
             echo json_encode(array("server_response" => $response));

         }
    else
    {
        $sql_id = "select user_id from tUserdetails where  email like '" .$email. "';";
        $result1 = mysqli_query($conn,$sql_id);
        if($result1)
        {
            while($row = mysqli_fetch_array($result1))
            {
                $id = $row[0];
            }
             $response = array();
             $code = "reg_true";
             $message = "registration success thank you ..... your id is ".$id;
             array_push($response,array("code" => $code,"message" => $message));
             echo json_encode(array("server_response" => $response));
    }
}

        mysqli_close($conn);
}

  ?>