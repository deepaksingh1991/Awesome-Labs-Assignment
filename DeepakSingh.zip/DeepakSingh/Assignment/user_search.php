<?php 
include 'connection.php';
$user_id = $_POST['user_id']; 

$user_id = mysqli_real_escape_string($conn,$user_id);

///*$name = "deepak";
/*$email = "deepak@gmail.com";
$contact_number =  "8156973493";
$gender = "male";
$address = "Uttar Pradesh";*/
$response = array();
$sql_query = "select name,email,contact_number,gender,address from tUserdetails where user_id = '" .$user_id. "';";
$result = mysqli_query($conn,$sql_query);

      
         if(!$result)
        {
             $response = array();
             $code = "reg_false";
             $message = "Some Server Error occured try again .....";
             array_push($response,array("code" => $code, "message" => $message));
             echo json_encode(array("server_response" => $response));

         }
    else
    {
        
    $row = mysqli_num_rows($result);

        if($row>0)
        {
            while($row = mysqli_fetch_array($result))
            {
               
             array_push($response,array("code"=> "reg_true","name" => $row[0],"email" => $row[1],"contact"=>$row[2],"gender"=>$row[3],"address"=>$row[4]));
             echo json_encode(array("server_response" => $response));
    }

}
else
{
     array_push($response,array("code" => "reg_false", "message" => "user details is not available"));
     echo json_encode(array("server_response" => $response));
}

        mysqli_close($conn);
}

  ?>