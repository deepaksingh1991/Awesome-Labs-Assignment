package com.parking.deepaksingh.userdetails;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by DEEPAK SINGH on 5/21/2016.
 */
public class SearchUserDetails extends AppCompatActivity implements View.OnClickListener {

    EditText user_id;
    Button search;
    TextView name, email, contact, gender, address;
    String user;
    AlertDialog.Builder alertDialog;
    ProgressDialog progressDialog;
    RequestQueue requestQueue;
    String url = "http://10.0.3.2/Assignment/user_search.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_user_details);
        name = (TextView) findViewById(R.id.userName1);
        email = (TextView) findViewById(R.id.userEmail1);
        contact = (TextView) findViewById(R.id.userContact1);
        gender = (TextView) findViewById(R.id.userGender1);
        address = (TextView) findViewById(R.id.userAddress1);
        user_id = (EditText) findViewById(R.id.user_id);
        search = (Button) findViewById(R.id.btn_search);
        search.setOnClickListener(this);
        requestQueue = Volley.newRequestQueue(this);
    }

    @Override
    public void onClick(View v) {
        user = user_id.getText().toString();
        if (user.equals("")) {
            user_id.setError("please enter user_id");
        } else {

            progressDialog = new ProgressDialog(SearchUserDetails.this);
            progressDialog.setTitle("Please Wait");
            progressDialog.setMessage("Connecting to Server....");
            progressDialog.setCancelable(false);
            progressDialog.show();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        Thread.sleep(5000);
                        progressDialog.dismiss();
                        JSONObject json = new JSONObject(response);
                        JSONArray jsonArray = json.getJSONArray("server_response");
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        String code = jsonObject.getString("code");
                        if (code.equals("reg_false")) {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                String code1 = jsonObj.getString("code");
                                String message = jsonObject.getString("message");
                                alertDialog = new AlertDialog.Builder(SearchUserDetails.this);
                                alertDialog.setTitle("Failed");
                                alertDialog.setMessage(message);
                                alertDialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        user_id.setText("");
                                        dialog.dismiss();
                                    }
                                });
                                AlertDialog builder = alertDialog.create();
                                builder.show();
                            }

                        } else if (code.equals("reg_true")) {
                            user_id.setText("");
                            for (int j = 0; j < response.length(); j++) {
                                JSONObject jsonObj = jsonArray.getJSONObject(j);
                                String code1 = jsonObj.getString("code");

                                String name1 = jsonObj.getString("name");
                                String email1 = jsonObj.getString("email");
                                String contact1 = jsonObj.getString("contact");
                                String gender1 = jsonObj.getString("gender");
                                String address1 = jsonObj.getString("address");
                                name.setText(name1);
                                email.setText(email1);
                                contact.setText(contact1);
                                gender.setText(gender1);
                                address.setText(address1);



                            }

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }


                }


            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("user_id", user);

                    return params;
                }
            };
            requestQueue.add(stringRequest);

        }
    }
}