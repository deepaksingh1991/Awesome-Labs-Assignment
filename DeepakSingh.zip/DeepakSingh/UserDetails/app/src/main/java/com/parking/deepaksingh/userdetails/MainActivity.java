package com.parking.deepaksingh.userdetails;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText user_name,user_email,user_contact,user_address;
    Button btn_user_registration;
    String  name,email,contact_number,gender,address;
    AlertDialog.Builder alertDialog;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String namePattern = "[a-zA-Z]+";
    RequestQueue requestQueue;
    ProgressDialog progressDialog;
    String url = "http://10.0.3.2/Assignment/userdetails.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user_name = (EditText) findViewById(R.id.user_name);
        user_email = (EditText) findViewById(R.id.user_email);
        user_contact = (EditText) findViewById(R.id.user_phone);
        user_address = (EditText) findViewById(R.id.user_address);
        btn_user_registration = (Button) findViewById(R.id.btn_submit);
        btn_user_registration.setOnClickListener(this);
       requestQueue = Volley.newRequestQueue(this);

    }


    public void selectGender(View view)
    {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId())
        {
            case R.id.male:
                if(checked)
                {
                    gender = "Male";
                }
                break;
            case R.id.female:
                if(checked)
                {
                    gender = "Female";

                }
                break;


        }



    }

    @Override
    public void onClick(View v) {

            name = user_name.getText().toString();
            email = user_email.getText().toString();
            contact_number = user_contact.getText().toString();
            address = user_address.getText().toString();
        if(name.equals("") || email.equals("") || contact_number.equals("") || gender.equals("") || address.equals(""))
        {
            alertDialog = new AlertDialog.Builder(MainActivity.this);
             alertDialog.setTitle("SomeThing Went Wrong");
            alertDialog.setMessage("Please fill all the field...");
            alertDialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            AlertDialog builder = alertDialog.create();
            builder.show();
        }
        else if (!name.matches(namePattern))
        {
                 user_name.setError("Invalid Name");
        }
        else if(!email.matches(emailPattern))
        {
            user_email.setError("please enter the correct email address");
        }
        else if(contact_number.length() != 10)
        {
            user_contact.setError("please enter 10 digit number");
        }
        else
        {
            progressDialog= new ProgressDialog(MainActivity.this);
            progressDialog.setTitle("Please Wait");
            progressDialog.setMessage("Connecting to Server....");
            progressDialog.setCancelable(false);
            progressDialog.show();
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        Thread.sleep(5000);
                         progressDialog.dismiss();
                        JSONObject json = new JSONObject(response);
                        JSONArray jsonArray = json.getJSONArray("server_response");
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        String code = jsonObject.getString("code");
                        if(code.equals("reg_false"))
                        {
                            for (int i=0; i<response.length();i++)
                            {
                                JSONObject jsonObj = jsonArray.getJSONObject(i);
                                String code1 = jsonObj.getString("code");
                                String message = jsonObject.getString("message");
                                alertDialog = new AlertDialog.Builder(MainActivity.this);
                                alertDialog.setTitle("Failed");
                                alertDialog.setMessage(message);
                                alertDialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        user_name.setText("");
                                        user_email.setText("");
                                        user_contact.setText("");
                                        user_address.setText("");
                                        dialog.dismiss();
                                    }
                                });
                              AlertDialog builder = alertDialog.create();
                                builder.show();
                            }

                        }
                        else if(code.equals("reg_true"))
                        {
                            for (int j=0; j<response.length();j++)
                            {
                                JSONObject jsonObj = jsonArray.getJSONObject(j);
                                String code1 = jsonObj.getString("code");

                                String message = jsonObject.getString("message");
                                alertDialog = new AlertDialog.Builder(MainActivity.this);
                                alertDialog.setTitle("Success");
                                alertDialog.setMessage(message);
                                alertDialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent intent = new Intent(MainActivity.this,SearchUserDetails.class);
                                        startActivity(intent);
                                        dialog.dismiss();
                                    }
                                });
                                AlertDialog builder = alertDialog.create();

                                builder.show();
                            }

                        }


                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }



                }


            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("user_name", name);
                    params.put("user_email", email);
                    params.put("user_contact", contact_number);
                    params.put("user_gender",gender);
                    params.put("user_address", address);

                    return params;
                }
            };
            requestQueue.add(stringRequest);

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        user_name.setText("");
        user_email.setText("");
        user_contact.setText("");
        user_address.setText("");
        user_address.setText("");
    }
}
